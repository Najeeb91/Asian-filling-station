# PumpOS Master Prototype

## What was combined
This repository combines the strongest ideas from the supplied technical specification and the simplified mobile-first prototype.

### UX
- Common Daily Summary on opening.
- Departments are clickable.
- Daily Update Settings is separate from department Master Settings.
- Master Settings can expose selected items to Daily Update.
- Sale shows the current rate but does not edit the rate.
- Customer search + clickable customer profiles.
- Today's credit customers and amounts.
- Receive Payment keeps the transaction intentionally simple.

### Domain
- Nozzle opening/closing/testing calculations.
- Meter rollback and invalid testing protection.
- Fuel-rate calculation.
- Credit customer balance.
- Payment modes.
- Banking import entry point.
- Tank/Dip Charts department placeholder.
- Reports and audit architecture.

### Five-expert design
Dieter Rams = simplicity.
Don Norman = error prevention.
Alan Cooper = task-first workflow.
Steve Wozniak = reliable calculation/data handling.
Jeff Bezos = scalable architecture.

## Quality modes
`/recorrection` `/recheck` `/simple` `/excellent` `/autoimprove` `/raretozeroerror`

## Important
This is a GitHub-ready source prototype, not a claim of production deployment. The UI intentionally marks backend-dependent features that still require implementation: authentication/authorization, PostgreSQL persistence wiring, bank OCR/import, official dip-chart data validation, SMS/WhatsApp provider integration, encrypted scheduled backups, and immutable server-side audit logging.

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`
4. Open the local Next.js URL.

For production, add a managed PostgreSQL/Supabase database, secrets, migrations, authentication, server-side authorization and automated tests before deployment.
