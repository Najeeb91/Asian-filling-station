import "./globals.css";
export const metadata={title:"PumpOS Master",description:"Petrol pump operations and reconciliation prototype"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}