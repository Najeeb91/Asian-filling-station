 "use client";
import {useMemo,useState} from "react";

type Fuel="PETROL"|"DIESEL";
type Sale={id:number;fuel:Fuel;litres:number;rate:number;amount:number;mode:string;customer?:string};
type Customer={id:number;name:string;phone:string;limit:number;outstanding:number};
type Nozzle={id:number;label:string;fuel:Fuel;opening:number;closing:number;testing:number};

const initialNozzles:Nozzle[]=[
{id:1,label:"Pump 1 • Nozzle A",fuel:"PETROL",opening:14230.5,closing:14590.2,testing:5},
{id:2,label:"Pump 1 • Nozzle B",fuel:"DIESEL",opening:88120,closing:88640.5,testing:0}
];
const initialCustomers:Customer[]=[
{id:1,name:"ABC Transport",phone:"98XXXXXX01",limit:50000,outstanding:12000},
{id:2,name:"XYZ Logistics",phone:"98XXXXXX02",limit:30000,outstanding:8000}
];

export default function Home(){
 const [tab,setTab]=useState("home");
 const [petrol,setPetrol]=useState(95.5),[diesel,setDiesel]=useState(88.2);
 const [nozzles,setNozzles]=useState(initialNozzles);
 const [customers,setCustomers]=useState(initialCustomers);
 const [sales,setSales]=useState<Sale[]>([]);
 const [payment,setPayment]=useState(0),[paymentMode,setPaymentMode]=useState("Cash");
 const [customerSearch,setCustomerSearch]=useState("");
 const [selectedCustomer,setSelectedCustomer]=useState<number|null>(null);
 const [showAuto,setShowAuto]=useState(false);

 const audit=useMemo(()=>{
   let litres=0,revenue=0;
   const rows=nozzles.map(n=>{
     const gross=Math.max(0,n.closing-n.opening), net=Math.max(0,gross-n.testing);
     const rate=n.fuel==="PETROL"?petrol:diesel, amount=net*rate;
     litres+=net; revenue+=amount;
     return {...n,gross,net,rate,amount,rollback:n.closing<n.opening,invalidTest:n.testing>gross};
   });
   const nonCash=sales.filter(s=>s.mode!=="Cash").reduce((a,s)=>a+s.amount,0);
   return {rows,litres,revenue,nonCash};
 },[nozzles,petrol,diesel,sales]);

 const filtered=customers.filter(c=>c.name.toLowerCase().includes(customerSearch.toLowerCase())||c.phone.includes(customerSearch));
 const creditSales=sales.filter(s=>s.mode==="Credit");
 const outstanding=customers.reduce((a,c)=>a+c.outstanding,0);

 function addSale(fuel:Fuel,litres:number,mode="Cash"){
   if(litres<=0)return;
   const rate=fuel==="PETROL"?petrol:diesel, amount=litres*rate;
   if(mode==="Credit"&&selectedCustomer){
     setCustomers(cs=>cs.map(c=>c.id===selectedCustomer?{...c,outstanding:c.outstanding+amount}:c));
   }
   setSales(s=>[...s,{id:Date.now(),fuel,litres,rate,amount,mode,customer:selectedCustomer?customers.find(c=>c.id===selectedCustomer)?.name:undefined}]);
   setTab("home");
 }
 function updateNozzle(id:number,key:"closing"|"testing",v:number){
   setNozzles(ns=>ns.map(n=>n.id===id?{...n,[key]:v}:n));
 }
 return <div className="wrap">
  <header className="top"><div><div className="brand">PumpOS</div><div className="sub">India-ready petrol pump operations • prototype</div></div><button className="ghost" onClick={()=>setShowAuto(true)}>Auto Improve</button></header>

  {tab==="home"&&<><div className="hero"><div className="title">Daily Summary</div><div className="muted">Everything commonly updated today stays here. Department-specific configuration remains in Master Settings.</div></div>
   <div className="grid">
    <div className="card"><div className="muted">Fuel sold</div><div className="num">{audit.litres.toFixed(2)} L</div></div>
    <div className="card"><div className="muted">Today's sales</div><div className="num">₹{audit.revenue.toFixed(2)}</div></div>
    <div className="card"><div className="muted">Today's credit sales</div><div className="num">₹{creditSales.reduce((a,s)=>a+s.amount,0).toFixed(2)}</div></div>
    <div className="card"><div className="muted">Total outstanding</div><div className="num">₹{outstanding.toFixed(2)}</div></div>
   </div>
   <div className="section">Quick Actions</div><div className="grid">
    <button className="primary" onClick={()=>setTab("sale")}>＋ Fuel Sale</button><button className="ghost" onClick={()=>setTab("payment")}>Receive Payment</button>
   </div>
   <div className="section">Departments</div><div className="grid">
    {["Customer","Fuel & Nozzles","Banking","Expenses","Reports","Master Settings"].map(x=><button key={x} className="card" onClick={()=>setTab(x.toLowerCase())}>{x}</button>)}
   </div>
   <div className="section">Daily Update Settings</div><div className="card"><div className="muted">Common updates</div><p>Fuel rates • nozzle readings • cash/UPI/card totals • daily notes</p><button className="ghost" onClick={()=>setTab("daily")}>Open Daily Updates</button></div>
  </>}

  {tab==="sale"&&<Screen title="Fuel Sale" back={()=>setTab("home")}><div className="card stack"><select id="sf"><option>PETROL</option><option>DIESEL</option></select><input id="sl" type="number" min="0" placeholder="Litres"/><button className="primary" onClick={()=>{const f=(document.getElementById("sf") as HTMLSelectElement).value as Fuel; const q=+(document.getElementById("sl") as HTMLInputElement).value;addSale(f,q)}}>Record Sale</button><div className="muted">Rate is displayed automatically; it is not editable from the sale screen.</div></div></Screen>}

  {tab==="payment"&&<Screen title="Receive Payment" back={()=>setTab("home")}><div className="card stack"><input type="number" value={payment||""} onChange={e=>setPayment(+e.target.value)} placeholder="₹ Amount"/><select value={paymentMode} onChange={e=>setPaymentMode(e.target.value)}><option>Cash</option><option>UPI</option><option>Card</option><option>Bank Transfer</option></select><button className="primary" onClick={()=>{if(payment>0){setSales(s=>[...s,{id:Date.now(),fuel:"PETROL",litres:0,rate:0,amount:payment,mode:paymentMode}]);setPayment(0);setTab("home")}}}>Save Payment</button></div></Screen>}

  {tab==="customer"&&<Screen title="Customer Department" back={()=>setTab("home")}><div className="card stack"><input placeholder="Search customers" value={customerSearch} onChange={e=>setCustomerSearch(e.target.value)}/><div className="section">Total Customers</div><div className="num">{customers.length}</div>{filtered.map(c=><button className="card" key={c.id} onClick={()=>setSelectedCustomer(c.id)}><div className="row"><b>{c.name}</b><span>₹{c.outstanding.toFixed(0)}</span></div><div className="small">{c.phone} • Limit ₹{c.limit.toFixed(0)}</div></button>)}{selectedCustomer&&<div className="card"><b>Selected: {customers.find(c=>c.id===selectedCustomer)?.name}</b><button className="primary" style={{width:"100%",marginTop:8}} onClick={()=>setTab("sale")}>Make Credit Sale</button></div>}<div className="section">Today's Credit Customers</div>{creditSales.map(s=><div className="row card" key={s.id}><span>{s.customer||"Customer"}</span><b>₹{s.amount.toFixed(2)}</b></div>)}</div></Screen>}

  {tab==="fuel & nozzles"&&<Screen title="Fuel & Nozzles" back={()=>setTab("home")}><div className="grid"><div className="card"><b>Petrol rate</b><input type="number" value={petrol} onChange={e=>setPetrol(+e.target.value)}/></div><div className="card"><b>Diesel rate</b><input type="number" value={diesel} onChange={e=>setDiesel(+e.target.value)}/></div></div><div className="section">Nozzle readings</div>{nozzles.map(n=><div className="card stack" key={n.id}><b>{n.label} • {n.fuel}</b><input type="number" value={n.closing} onChange={e=>updateNozzle(n.id,"closing",+e.target.value)}/><input type="number" value={n.testing} onChange={e=>updateNozzle(n.id,"testing",+e.target.value)}/><div className="muted">Sold: {audit.rows.find(x=>x.id===n.id)?.net.toFixed(2)} L • ₹{audit.rows.find(x=>x.id===n.id)?.amount.toFixed(2)}</div></div>)}</Screen>}

  {tab==="banking"&&<Screen title="Banking" back={()=>setTab("home")}><div className="card"><b>Bank statement import</b><p className="muted">Prototype UI for PDF/image statement review. Production OCR, transaction matching and posting must run server-side with review controls.</p><input type="file" accept=".pdf,image/*,.csv,.xlsx"/><button className="primary" style={{width:"100%",marginTop:10}}>Review Imported Transactions</button></div></Screen>}

  {tab==="expenses"&&<Screen title="Expenses" back={()=>setTab("home")}><div className="card stack"><input placeholder="Expense description"/><input type="number" placeholder="₹ Amount"/><button className="primary">Save Expense</button></div></Screen>}
  {tab==="reports"&&<Screen title="Reports" back={()=>setTab("home")}><div className="grid">{["Daily Summary","Shift Reconciliation","Customer Ledger","Bank Reconciliation","Fuel Stock","Audit Log"].map(x=><button className="card" key={x}>{x}</button>)}</div></Screen>}
  {tab==="daily"&&<Screen title="Daily Update Settings" back={()=>setTab("home")}><div className="card"><p>Common update items are managed here.</p>{["Petrol Rate","Diesel Rate","Nozzle Readings","UPI Total","Card Total","Cash Total"].map(x=><div className="row card" key={x}><span>{x}</span><button className="ghost">Edit</button></div>)}</div></Screen>}
  {tab==="master settings"&&<Screen title="Master Settings" back={()=>setTab("home")}><div className="card"><p>Each department has its own master settings. Use <b>Add to Daily Update</b> to expose an item on the common daily page. Removal happens only from Daily Update Settings.</p>{["Customer","Fuel & Nozzles","Banking","Expenses","Notifications","Users & Roles","Tank & Dip Charts"].map(x=><div className="row card" key={x}><b>{x}</b><button className="ghost">Open</button></div>)}</div></Screen>}

  {showAuto&&<div style={{position:"fixed",inset:0,background:"#0f172a88",padding:16,display:"grid",placeItems:"center"}}><div className="card" style={{maxWidth:700,maxHeight:"90vh",overflow:"auto"}}><div className="row"><div className="title">Auto Improve / Recheck</div><button className="ghost" onClick={()=>setShowAuto(false)}>Close</button></div><div className="section">Quality checks</div>{[
   ["/recorrection","Recheck workflows for contradictory or unnecessary steps."],
   ["/recheck","Validate calculations, state transitions and UI actions."],
   ["/simple","Prefer the shortest understandable path on mobile."],
   ["/excellent","Combine strong UX, domain logic, security and scalability."],
   ["/raretozeroerror","Block invalid meter, credit and financial states before save."],
   ["/autoimprove","Keep identifying prototype gaps; never label unfinished integrations as functional."]
  ].map(([a,b])=><div className="card" key={a}><b>{a}</b><div className="small">{b}</div></div>)}
   <div className="alert"><b>Production gaps intentionally visible:</b> authentication, server-side authorization, real bank OCR/import, official dip-chart validation, notification provider integration, PostgreSQL persistence, encrypted backup job and immutable audit storage.</div>
  </div></div>}
 </div>
}
function Screen(p:{title:string;back:()=>void;children:React.ReactNode}){return <><button className="ghost" style={{marginTop:14}} onClick={p.back}>← Back</button><div className="hero"><div className="title">{p.title}</div></div>{p.children}</>}
