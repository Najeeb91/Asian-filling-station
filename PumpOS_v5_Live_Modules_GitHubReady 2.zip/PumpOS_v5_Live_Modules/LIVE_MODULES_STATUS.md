# PumpOS v5 Live Modules Status

## Functional now (when PostgreSQL + dependencies are configured)
- `/api/health` — real PostgreSQL connectivity check.
- `/api/customers` — real customer list/search/create.
- `/api/customers/[id]/ledger` — real customer ledger retrieval.
- `/api/settings` — real department setting read/upsert.
- `/api/daily-updates` — real daily-update read/remove.
- Domain calculation tests for meter validation and cash variance primitives.
- Prisma migration/seed commands.

## Requires external provider/account setup
- Production Vercel deployment
- Production Supabase/PostgreSQL credentials
- Bank OCR provider or extraction implementation
- SMS/WhatsApp provider credentials
- S3-compatible object storage credentials
- Production authentication/session provider

## Safety
No financial module is described as production-complete until server-side authorization, transactional persistence, audit logging, automated tests and staging UAT pass.
