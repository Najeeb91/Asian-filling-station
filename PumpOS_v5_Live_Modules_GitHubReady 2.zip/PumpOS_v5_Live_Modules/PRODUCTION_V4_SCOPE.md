# PumpOS v4 — Live Production Build Scope

## Goal
Convert the PumpOS production architecture into a deployable, secure, mobile-first station management system.

## 1. Authentication & RBAC
Roles:
- SUPER_ADMIN
- OWNER
- MANAGER
- OPERATOR
- ACCOUNTANT

Rules:
- Server-side authorization on every protected mutation.
- Session-based authentication with secure cookies.
- No financial action authorized solely by client UI.
- Manager approval for configured high-risk actions.
- Audit log for login, settings changes, overrides, shift closure and financial corrections.

## 2. PostgreSQL / Prisma
- Use Prisma migrations, not `db push`, for production.
- Foreign keys and unique constraints for station configuration.
- Decimal-safe money/volume calculations.
- Transactional writes for sales, ledgers, meter readings and reconciliation.
- Idempotency keys for imports and critical financial submissions.

## 3. Bank Import
Supported input:
- PDF
- CSV/XLSX where available
- Image/screenshot

Pipeline:
Upload → file validation → OCR/table extraction → transaction normalization → duplicate detection → confidence score → review queue → user confirmation → database posting.

Important:
OCR must never silently post uncertain financial data. Low-confidence rows require review.

## 4. Tank / Dip Chart
Each tank stores:
- capacity
- fuel type
- tank identity
- dip-chart version
- source document
- calibration date
- verification status

A station can upload its official chart. The system maps dip readings to litres only after validation/approval.

Never assume that two tanks of the same nominal KL capacity have identical official charts.

## 5. Fuel / Dispenser / Nozzle
Permanent station configuration:
Tank → Dispenser → Nozzle

Daily workflow:
Opening meter → closing meter → testing → net sale.

The user should not repeatedly recreate permanent nozzle configuration.

## 6. Daily Update + Master Settings
Every department has its own Master Settings.

A setting may be selected through:
`Add to Daily Update`

Daily Update is the operational daily-entry surface.

Removing it from Daily Update does not delete the underlying Master Setting.

Changing a value must use one authoritative persisted record so all views reflect the same value.

## 7. Customer Department
Customer dashboard:
- Search
- Add customer
- Total customers
- Today's credit customers
- Today's credit sales
- Today's payments
- Total outstanding
- Overdue / credit-limit alerts
- Reports

Customer credit transactions update:
Customer balance + Customer ledger + Sale record + audit trail atomically.

## 8. Notifications
Provider abstraction for:
- SMS
- WhatsApp

Use templates, delivery status, retry policy and opt-out/consent controls.

Examples:
- overdue alert
- credit-limit warning
- shift discrepancy
- daily summary
- backup failure

## 9. Backup / Restore
Automated encrypted backups with:
- retention policy
- backup health record
- restore procedure
- periodic restore verification

A backup is not considered reliable until restoration has been tested.

## 10. Reports
Include:
- daily sales
- shift reconciliation
- cash variance
- fuel volume
- customer credit
- outstanding/collections
- tank stock
- dip history
- expenses
- bank transactions
- audit history

## 11. Security
Required before live use:
- secret management
- input validation
- authorization checks
- rate limiting
- upload restrictions
- malware/file-type validation
- CSRF/session protection as applicable
- secure headers
- database least-privilege credentials
- audit logging
- error redaction
- dependency/security scanning

## 12. Deployment
Target:
- Vercel for Next.js
- Supabase PostgreSQL
- object storage for encrypted backups
- external SMS/WhatsApp provider

Deployment sequence:
local tests → staging database → migration → seed station configuration → UAT → production environment → production migration → smoke tests → monitoring.

## 13. Definition of Done
A module is not "complete" merely because its page opens.

A critical workflow is complete only when:
UI → server validation → database transaction → audit trail → error handling → reload persistence → authorization test → automated test.

## 14. Zero-error principle
"Zero error" means the system actively prevents, detects, explains and records errors. It does not mean software can guarantee zero human or external-system errors.
