# PumpOS v3 Production Architecture

Mobile-first petrol-station operations system based on the finalized Master Settings ↔ Daily Update architecture.

## Stack
- Next.js 14 + TypeScript
- PostgreSQL + Prisma
- Zod validation
- Server-authoritative financial calculations
- Transactional customer ledger and shift reconciliation

## Run
1. `cp .env.example .env`
2. Set `DATABASE_URL` and `DIRECT_URL`.
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. `npm run db:seed`
7. `npm run dev`

Open `http://localhost:3000`.

## Production next steps
Authentication/RBAC must be connected before deployment. Banking OCR/import must use a trusted extraction service and a review queue. Object-storage backups, SMS/WhatsApp, rate-management approvals, official dip-chart verification and comprehensive automated tests should be added before production launch.

## Architecture rule
Do not patch individual UI buttons. Domain state lives in PostgreSQL. UI calls server APIs. Financial changes occur in database transactions and produce audit records. Master Settings are the source of configuration; Daily Update is a selected operational view of those same settings.
