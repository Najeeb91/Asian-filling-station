# PumpOS v3.1 — Recheck & Improvement Pass

## Release intent
This build keeps the v3 production architecture and adds a formal verification checklist so the project is not treated as a UI-only prototype.

## Rechecked architecture
- Next.js + TypeScript application structure
- Prisma + PostgreSQL data layer
- Department-specific Master Settings
- Master Settings ↔ Daily Update relationship
- Customer ledger / credit architecture
- Fuel / tank / dispenser / nozzle relationships
- Shift reconciliation architecture
- Audit-log architecture
- Environment-variable separation
- GitHub-ready project structure

## Before live deployment
These items require real credentials, infrastructure, and integration testing:
1. Authentication and role-based authorization
2. Production database migrations
3. Bank PDF/image OCR with human verification
4. Official fuel-price workflow
5. Verified tank dip-chart import and calibration
6. SMS/WhatsApp provider integration
7. Automated encrypted backup and restore test
8. Security review and secret rotation
9. End-to-end tests using real station scenarios
10. Vercel/Supabase production deployment
11. Monitoring, error reporting, and audit retention
12. Final UAT by station owner/manager

## Design rule
No critical financial action should rely only on client-side state. The server/database must validate and persist the transaction, with an audit trail where appropriate.
