import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim() ?? "";
  const customers = await prisma.customer.findMany({
    where: q ? { OR: [{ accountName: { contains: q, mode: "insensitive" } }, { phone: { contains: q } }] } : undefined,
    orderBy: { accountName: "asc" },
    take: 100,
  });
  return NextResponse.json(customers);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body.accountName || !body.phone) return NextResponse.json({ error: "accountName and phone are required" }, { status: 400 });
  const customer = await prisma.customer.create({
    data: {
      accountName: String(body.accountName).trim(),
      phone: String(body.phone).trim(),
      creditLimit: body.creditLimit ?? 0,
      currentBalance: 0,
    },
  });
  return NextResponse.json(customer, { status: 201 });
}
