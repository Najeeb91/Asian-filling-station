import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const department = req.nextUrl.searchParams.get("department");
  const items = await prisma.stationSetting.findMany({
    where: { dailyEnabled: true, ...(department ? { department } : {}) },
    orderBy: [{ department: "asc" }, { key: "asc" }],
  });
  return NextResponse.json(items);
}

export async function DELETE(req: NextRequest) {
  const body = await req.json();
  if (!body.department || !body.key) return NextResponse.json({ error: "department and key are required" }, { status: 400 });
  const item = await prisma.stationSetting.update({
    where: { department_key: { department: body.department, key: body.key } },
    data: { dailyEnabled: false },
  });
  return NextResponse.json(item);
}
