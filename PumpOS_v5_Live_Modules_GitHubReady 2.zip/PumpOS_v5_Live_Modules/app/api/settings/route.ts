import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const department = req.nextUrl.searchParams.get("department");
  const settings = await prisma.stationSetting.findMany({
    where: department ? { department } : undefined,
    orderBy: { key: "asc" },
  });
  return NextResponse.json(settings);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body.department || !body.key) return NextResponse.json({ error: "department and key are required" }, { status: 400 });
  const setting = await prisma.stationSetting.upsert({
    where: { department_key: { department: body.department, key: body.key } },
    create: { department: body.department, key: body.key, value: body.value ?? "", dailyEnabled: Boolean(body.dailyEnabled) },
    update: { value: body.value ?? "", dailyEnabled: Boolean(body.dailyEnabled) },
  });
  return NextResponse.json(setting);
}
