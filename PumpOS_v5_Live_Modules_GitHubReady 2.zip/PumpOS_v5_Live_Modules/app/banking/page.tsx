import Link from "next/link";
export default function Banking(){return <div className="shell"><header className="header"><b>Banking</b><br/><small>Statement import & reconciliation</small></header><main className="main"><Link href="/">← Home</Link>
<div className="card"><b>Import Bank Statement</b><p className="muted">Production workflow: upload PDF/screenshot → extract → validate → duplicate check → user review → confirm posting.</p><input className="input" type="file" accept=".pdf,image/*"/></div>
<div className="alert">Imported transactions are never silently posted. Uncertain or duplicate records become review exceptions.</div>
<div className="title">Reconciliation</div><div className="item"><span>Matched Transactions</span><b>0</b></div><div className="item"><span>Unmatched Transactions</span><b>0</b></div>
</main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>}
