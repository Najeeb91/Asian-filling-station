import { prisma } from "@/lib/prisma";
import Link from "next/link";
export default async function Customers(){
 const s=await prisma.station.findFirst(); if(!s)return <main className="main">No station configured.</main>;
 const cs=await prisma.customer.findMany({where:{stationId:s.id},orderBy:{accountName:"asc"}});
 const out=cs.reduce((a,c)=>a+Number(c.currentBalance),0);
 return <div className="shell"><header className="header"><b>Customers</b><br/><small>Customer ledger & credit control</small></header><main className="main">
 <Link href="/">← Home</Link><div className="grid"><div className="card"><div className="muted">Total Customers</div><div className="metric">{cs.length}</div></div><div className="card"><div className="muted">Total Outstanding</div><div className="metric">₹{out.toLocaleString("en-IN")}</div></div></div>
 <input className="input" placeholder="Search customers"/>
 <div className="title">Customer List</div>
 {cs.map(c=><div className="item" key={c.id}><span><b>{c.accountName}</b><br/><span className="muted">{c.phone??"No phone"} • Outstanding ₹{Number(c.currentBalance).toLocaleString("en-IN")} / Limit ₹{Number(c.creditLimit).toLocaleString("en-IN")}</span></span><b>›</b></div>)}
 </main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>
}