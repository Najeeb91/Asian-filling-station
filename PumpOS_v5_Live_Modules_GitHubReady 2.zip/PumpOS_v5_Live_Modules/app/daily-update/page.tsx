import { prisma } from "@/lib/prisma";
import Link from "next/link";
export default async function Daily(){
 const s=await prisma.station.findFirst(); const items=s?await prisma.dailyUpdateItem.findMany({where:{stationId:s.id,isActive:true},include:{setting:true},orderBy:{sortOrder:"asc"}}):[];
 return <div className="shell"><header className="header"><b>Daily Update</b><br/><small>Only selected daily items</small></header><main className="main"><Link href="/">← Home</Link>
 {items.map(i=><div className="item" key={i.id}><span><b>{i.setting.label}</b><br/><span className="muted">{i.setting.value}</span></span><button className="btn danger">Remove</button></div>)}
 {!items.length&&<div className="card">No settings have been added to Daily Update.</div>}
 </main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>
}