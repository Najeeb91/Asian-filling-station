import { prisma } from "@/lib/prisma"; import Link from "next/link";
export default async function Fuel(){
 const s=await prisma.station.findFirst(); if(!s)return <main className="main">No station.</main>;
 const p=await prisma.fuelPrice.findMany({where:{stationId:s.id,isActive:true},orderBy:{fuelType:"asc"}});
 return <div className="shell"><header className="header"><b>Fuel & Sales</b><br/><small>Rates displayed; editing belongs to Fuel Settings</small></header><main className="main"><Link href="/">← Home</Link>
 <div className="title">Current Rates</div>{p.map(x=><div className="item" key={x.id}><b>{x.fuelType}</b><b>₹{Number(x.sellingPrice).toFixed(2)}/L</b></div>)}
 <div className="card">Nozzle closing readings and sales posting are server-validated in production APIs. Rates are not editable from the sales screen.</div>
 </main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>
}