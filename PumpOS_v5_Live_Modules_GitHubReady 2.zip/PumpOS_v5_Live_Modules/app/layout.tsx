import "./globals.css";
export const metadata = { title: "PumpOS v3", description: "Petrol station operations platform" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en-IN"><body>{children}</body></html>;
}
