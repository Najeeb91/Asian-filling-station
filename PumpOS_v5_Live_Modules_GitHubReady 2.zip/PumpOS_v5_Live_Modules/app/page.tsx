import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function Home() {
  const station = await prisma.station.findFirst();
  const customers = station ? await prisma.customer.count({where:{stationId:station.id}}) : 0;
  const outstanding = station ? await prisma.customer.aggregate({where:{stationId:station.id},_sum:{currentBalance:true}}) : {_sum:{currentBalance:null}};
  const tanks = station ? await prisma.tank.findMany({where:{stationId:station.id}}) : [];

  return <div className="shell">
    <header className="header"><b>{station?.name ?? "PumpOS"}</b><br/><small>Production v3 • PostgreSQL / Prisma</small></header>
    <main className="main">
      <div className="title">Today's Summary</div>
      <div className="grid">
        <div className="card"><div className="muted">Customers</div><div className="metric">{customers}</div></div>
        <div className="card"><div className="muted">Outstanding</div><div className="metric">₹{Number(outstanding._sum.currentBalance ?? 0).toLocaleString("en-IN")}</div></div>
      </div>
      <div className="title">Departments</div>
      {[
        ["👥","Customers","/customers"],["⛽","Fuel & Sales","/fuel"],
        ["📦","Tanks & Inventory","/tanks"],["🏦","Banking","/banking"],
        ["🧾","Shift & Reconciliation","/shift"],["⚙️","Master Settings","/settings"]
      ].map(([icon,name,url])=><Link href={url} className="item" key={url}><span><b>{icon} {name}</b><br/><span className="muted">Open department</span></span><b>›</b></Link>)}
      <div className="title">Inventory Alerts</div>
      {tanks.filter(t=>Number(t.currentStock)<Number(t.deadStockLevel)).map(t=><div className="alert" key={t.id}>Low stock: {t.tankNumber}</div>)}
      {!tanks.some(t=>Number(t.currentStock)<Number(t.deadStockLevel)) && <div className="ok">No critical tank alerts.</div>}
    </main>
    <nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav>
  </div>
}
