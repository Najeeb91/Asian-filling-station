import { prisma } from "@/lib/prisma";
import Link from "next/link";
export default async function Settings(){
 const s=await prisma.station.findFirst(); const groups=["General","Fuel","Customers","Tanks & Inventory","Sales & Payments","Shift","Banking","Expenses","Users & Permissions","Reports","Notifications","Security & Audit","Backup"];
 const settings=s?await prisma.masterSetting.findMany({where:{stationId:s.id},orderBy:[{department:"asc"},{label:"asc"}]}):[];
 return <div className="shell"><header className="header"><b>Master Settings</b><br/><small>Department-specific configuration</small></header><main className="main"><Link href="/">← Home</Link>
 <div className="card"><b>Master Settings ↔ Daily Update</b><p className="muted">A setting is edited once and its current value is used everywhere. “Add to Daily Update” controls visibility in the daily workflow; Remove only removes it from Daily Update.</p></div>
 {groups.map(g=><div key={g}><div className="title">{g}</div>{settings.filter(x=>x.department===g).map(x=><div className="item" key={x.id}><span><b>{x.label}</b><br/><span className="muted">{x.value}</span></span><span className="actions"><button className="btn">Edit</button><button className="btn">Add to Daily</button></span></div>)}</div>)}
 </main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>
}