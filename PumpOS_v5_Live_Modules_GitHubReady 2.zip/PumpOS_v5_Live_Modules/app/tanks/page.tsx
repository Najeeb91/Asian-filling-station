import { prisma } from "@/lib/prisma"; import Link from "next/link";
export default async function Tanks(){const s=await prisma.station.findFirst(); const ts=s?await prisma.tank.findMany({where:{stationId:s.id},include:{dipChart:true}}):[];
return <div className="shell"><header className="header"><b>Tanks & Inventory</b><br/><small>Stock, dip and official chart management</small></header><main className="main"><Link href="/">← Home</Link>
{ts.map(t=><div className="card" key={t.id}><b>{t.tankNumber} • {t.fuelType}</b><p className="muted">Capacity {Number(t.capacityLitres).toLocaleString()} L • Stock {Number(t.currentStock).toLocaleString()} L</p><div className="actions"><button className="btn">Record Dip</button><button className="btn">View Dip Chart</button><button className="btn">Tank Settings</button></div></div>)}
</main><nav className="nav"><Link href="/">Home</Link><Link href="/daily-update">Daily</Link><Link href="/settings">Settings</Link></nav></div>}
