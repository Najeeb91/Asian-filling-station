# PumpOS v4 Acceptance Tests

## Critical workflows

### Authentication
- Correct credentials authenticate.
- Incorrect credentials fail.
- Inactive user cannot authenticate.
- Unauthorized role cannot mutate protected resources.

### Customer credit
- Credit sale increases outstanding balance exactly once.
- Duplicate submission does not double-post.
- Payment decreases balance exactly once.
- Credit-limit warning appears at configured threshold.
- Ledger and sale remain consistent after reload.

### Meter reconciliation
- Closing < opening is rejected.
- Testing volume greater than gross meter delta is rejected.
- Decimal calculations remain exact within defined precision.
- Shift close is atomic.
- Discrepancy is persisted and auditable.

### Bank import
- Invalid file rejected.
- Duplicate transaction detected.
- OCR uncertainty enters review queue.
- Confirmed transaction is posted once.
- Original upload remains traceable.

### Dip chart
- Official chart can be uploaded and versioned.
- Unverified chart cannot silently become active.
- Active chart is tied to a specific tank.
- Historical readings retain their chart/version reference.

### Settings
- Department Master Setting persists.
- Add to Daily Update creates/activates the daily item.
- Remove from Daily Update removes only daily visibility.
- Master setting remains intact.
- Changes are reflected consistently across both views.

### Backup
- Backup is produced.
- Encryption metadata is stored.
- Backup failure is visible.
- Restore test succeeds in staging.

## Release gate
No production release until all critical workflows pass automated tests and staging UAT.
