# PumpOS v4 Core Data Flows

## Daily update
Master Setting
→ Add to Daily Update
→ Daily Update Item
→ Daily entry
→ Server validation
→ Persist
→ Audit
→ Dashboard refresh

## Fuel sale
Nozzle meter delta
→ testing deduction
→ net litres
→ active approved fuel price
→ sale value
→ payment allocation
→ reconciliation
→ audit

## Credit sale
Customer
→ credit-limit validation
→ Sale
→ CustomerLedger
→ Customer balance
→ alerts
→ audit

## Bank import
PDF/Image/CSV
→ secure upload
→ extraction/OCR
→ normalization
→ duplicate detection
→ confidence scoring
→ human review
→ posting
→ audit

## Tank dip
Tank
→ active verified dip-chart version
→ dip reading
→ litre conversion
→ stock comparison
→ variance alert
→ audit
