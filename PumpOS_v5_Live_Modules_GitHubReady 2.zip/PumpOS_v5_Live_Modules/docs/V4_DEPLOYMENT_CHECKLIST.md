# PumpOS v4 Deployment Checklist

## Before deployment
- [ ] Production environment variables configured outside source control.
- [ ] Supabase production database created.
- [ ] Prisma migration history reviewed.
- [ ] Staging migration tested.
- [ ] Seed/configuration reviewed.
- [ ] Authentication/RBAC tested.
- [ ] File upload limits and validation tested.
- [ ] OCR review workflow tested.
- [ ] Dip-chart verification tested.
- [ ] Notification provider tested.
- [ ] Backup completed.
- [ ] Restore tested.
- [ ] Security scan passed.
- [ ] Automated critical-path tests passed.
- [ ] Station UAT signed off.

## Production
- [ ] Apply Prisma migrations.
- [ ] Verify database connectivity.
- [ ] Verify authentication.
- [ ] Verify station configuration.
- [ ] Run smoke test.
- [ ] Verify backup.
- [ ] Verify monitoring.
- [ ] Verify audit logs.

## Rollback
- Keep previous application version available.
- Never delete historical financial records as a rollback mechanism.
- Use tested database migration rollback/forward strategy.
