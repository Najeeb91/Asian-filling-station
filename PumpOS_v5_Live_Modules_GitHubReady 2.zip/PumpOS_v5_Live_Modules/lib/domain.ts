export function money(value: unknown): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw new Error("Invalid monetary value");
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function meterSale(opening: unknown, closing: unknown, testing = 0) {
  const o = Number(opening), c = Number(closing), t = Number(testing);
  if (![o, c, t].every(Number.isFinite) || o < 0 || c < 0 || t < 0) {
    throw new Error("Invalid meter values");
  }
  if (c < o) throw new Error("Meter rollback detected");
  const gross = c - o;
  if (t > gross) throw new Error("Testing volume exceeds meter delta");
  return Math.round((gross - t + Number.EPSILON) * 100) / 100;
}

export function cashVariance(expected: unknown, actual: unknown) {
  const e = money(expected), a = money(actual);
  return Math.round((a - e + Number.EPSILON) * 100) / 100;
}
