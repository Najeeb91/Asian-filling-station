import { z } from "zod";

export const meterCloseSchema = z.object({
  shiftId: z.string().min(1),
  nozzleId: z.string().min(1),
  closingReading: z.coerce.number().finite().nonnegative(),
  testingVolume: z.coerce.number().finite().nonnegative().default(0)
});

export const settingSchema = z.object({
  stationId: z.string().min(1),
  department: z.string().min(1),
  key: z.string().min(1),
  value: z.string()
});

export const creditSaleSchema = z.object({
  shiftId: z.string().min(1),
  customerId: z.string().min(1),
  amount: z.coerce.number().positive(),
  fuelType: z.string().optional(),
  litres: z.coerce.number().nonnegative().optional()
});

export const paymentSchema = z.object({
  customerId: z.string().min(1),
  amount: z.coerce.number().positive(),
  description: z.string().min(1)
});
