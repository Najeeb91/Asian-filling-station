CREATE TABLE IF NOT EXISTS "StationSetting" (
  "id" TEXT NOT NULL,
  "department" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "value" JSONB,
  "dailyEnabled" BOOLEAN NOT NULL DEFAULT false,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "StationSetting_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "StationSetting_department_key_key" ON "StationSetting"("department","key");
CREATE INDEX IF NOT EXISTS "StationSetting_department_dailyEnabled_idx" ON "StationSetting"("department","dailyEnabled");
