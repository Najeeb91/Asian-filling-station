import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const settings = [
    ["CUSTOMERS", "credit_limit", false],
    ["CUSTOMERS", "overdue_alert_days", true],
    ["FUEL", "default_test_litres", true],
    ["FUEL", "show_price_on_sales", true],
  ] as const;
  for (const [department, key, dailyEnabled] of settings) {
    await prisma.stationSetting.upsert({
      where: { department_key: { department, key } },
      create: { department, key, value: "", dailyEnabled },
      update: { dailyEnabled },
    });
  }
  console.log("Seed complete");
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
