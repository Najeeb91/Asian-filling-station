import { prisma } from "../lib/prisma";
async function main() {
  await prisma.$queryRaw`SELECT 1`;
  console.log("PostgreSQL connection: OK");
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
