import { PrismaClient } from "@prisma/client";

export async function audit(
  tx: PrismaClient,
  input: {stationId:string; userId?:string; action:string; resource:string; recordId?:string; oldValue?:unknown; newValue?:unknown; reason?:string}
) {
  return tx.auditLog.create({
    data: {
      stationId: input.stationId,
      userId: input.userId,
      action: input.action,
      resource: input.resource,
      recordId: input.recordId,
      oldValue: input.oldValue as any,
      newValue: input.newValue as any,
      reason: input.reason
    }
  });
}
