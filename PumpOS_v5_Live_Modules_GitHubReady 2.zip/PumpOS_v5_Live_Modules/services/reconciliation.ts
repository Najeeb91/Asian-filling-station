import { PrismaClient, ShiftStatus, PaymentMode, LedgerType } from "@prisma/client";
import { Decimal } from "@prisma/client/runtime/library";

export async function closeShift(prisma: PrismaClient, shiftId: string, actualCash: Decimal, managerId: string) {
  return prisma.$transaction(async tx => {
    const shift = await tx.shift.findUnique({
      where: { id: shiftId },
      include: { sales: true }
    });
    if (!shift || shift.status !== ShiftStatus.OPEN) throw new Error("Shift is not open");

    const totalSales = shift.sales.reduce((a, s) => a.plus(s.amount), new Decimal(0));
    const nonCash = shift.sales
      .filter(s => s.paymentMode !== PaymentMode.CASH)
      .reduce((a, s) => a.plus(s.amount), new Decimal(0));

    const expectedCash = totalSales.minus(nonCash);
    const discrepancy = actualCash.minus(expectedCash);
    const status = discrepancy.abs().greaterThan(new Decimal(5))
      ? ShiftStatus.DISCREPANCY_FLAGGED
      : ShiftStatus.CLOSED;

    return tx.shift.update({
      where: { id: shiftId },
      data: {
        managerId,
        status,
        closedAt: new Date(),
        totalSales,
        expectedCash,
        actualCash,
        discrepancy
      }
    });
  });
}

export async function postCreditSale(prisma: PrismaClient, input: {
  shiftId:string; customerId:string; amount:Decimal; fuelType?:any; litres?:Decimal
}) {
  return prisma.$transaction(async tx => {
    const customer = await tx.customer.findUnique({ where: { id: input.customerId } });
    if (!customer) throw new Error("Customer not found");

    const newBalance = customer.currentBalance.plus(input.amount);
    if (newBalance.greaterThan(customer.creditLimit)) throw new Error("Credit limit exceeded");

    const sale = await tx.sale.create({
      data: {
        shiftId: input.shiftId,
        customerId: input.customerId,
        amount: input.amount,
        paymentMode: PaymentMode.CREDIT,
        fuelType: input.fuelType,
        litres: input.litres
      }
    });

    await tx.customer.update({
      where: { id: customer.id },
      data: { currentBalance: newBalance }
    });

    await tx.customerLedger.create({
      data: {
        customerId: customer.id,
        type: LedgerType.DEBIT,
        amount: input.amount,
        balanceAfter: newBalance,
        description: "Fuel credit sale"
      }
    });

    return sale;
  });
}
