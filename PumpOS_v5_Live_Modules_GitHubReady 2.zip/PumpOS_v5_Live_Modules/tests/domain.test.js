const test = require("node:test");
const assert = require("node:assert/strict");

function meterSale(o,c,t=0){
  if (![o,c,t].every(Number.isFinite) || o<0 || c<0 || t<0) throw new Error();
  if(c<o) throw new Error("rollback");
  const gross=c-o;
  if(t>gross) throw new Error("testing");
  return Math.round((gross-t)*100)/100;
}
test("meter sale calculation",()=>assert.equal(meterSale(100,150,5),45));
test("rollback rejected",()=>assert.throws(()=>meterSale(150,100,0)));
test("testing cannot exceed delta",()=>assert.throws(()=>meterSale(100,102,5)));
