# PumpOS ⛽

Automated petrol pump accounting, meter reconciliation & secure backup engine.

## Architecture

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript (strict mode)
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: NextAuth.js (Credentials)
- **State**: TanStack Query (React Query)
- **Styling**: Tailwind CSS
- **Backup**: AES-256-GCM encrypted S3 streaming

## Quick Start

```bash
# 1. Clone and install
git clone <repo> && cd pump-os
npm install

# 2. Setup environment
cp .env.example .env.local
# Edit .env.local with your database credentials

# 3. Start database (Docker)
docker-compose up -d db

# 4. Push schema and seed
npx prisma db push
npm run db:seed

# 5. Run dev server
npm run dev
```

## Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@pumpos.com | Admin@123 |
| Manager | manager@pumpos.com | Manager@123 |
| Operator | operator1@pumpos.com | Operator@123 |
| Accountant | accounts@pumpos.com | Accountant@123 |

## Key Features

- **Poka-Yoke Validation**: Meter rollbacks and negative volumes rejected before DB writes
- **Zero-Discrepancy Engine**: Cash variance calculated in serializable transactions
- **Fleet Credit Management**: Auto-updates customer balances with credit limit enforcement
- **Immutable Audit Trail**: Every shift sign-off, override, and price change logged
- **Encrypted Backups**: Streaming AES-256-GCM encryption directly to S3
- **Real-time Alerts**: Twilio SMS notifications for discrepancies and low stock

## Project Structure

```
pump-os/
├── prisma/              # Database schema & seed
├── src/
│   ├── app/             # Next.js App Router
│   │   ├── api/         # REST API routes
│   │   ├── dashboard/   # Dashboard page
│   │   ├── shifts/      # Shift management
│   │   └── login/       # Authentication
│   ├── components/      # React components
│   ├── lib/             # Utilities, auth, validation
│   ├── services/        # Business logic
│   ├── scripts/         # Backup/restore CLI
│   └── types/           # TypeScript types
├── tests/               # Vitest test suite
└── docker-compose.yml   # Local development stack
```

## Scripts

```bash
npm run dev           # Development server
npm run build         # Production build
npm run db:push       # Push schema to database
npm run db:seed       # Seed with demo data
npm run db:studio     # Open Prisma Studio
npm run backup        # Trigger encrypted database backup
npm run restore       # Restore from encrypted backup
npm run test          # Run test suite
npm run typecheck     # TypeScript type checking
```

## Security

- Role-based access control (RBAC) via middleware
- Input validation with Zod on all API routes
- Security headers (CSP, HSTS, X-Frame-Options)
- Audit logging for all sensitive operations
- Prepared statements via Prisma (SQL injection protection)
- AES-256-GCM authenticated encryption for backups

## License

MIT
