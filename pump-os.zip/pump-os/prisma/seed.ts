import { PrismaClient, Role, FuelType, PaymentMode } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding PumpOS database...');

  // Clear existing data
  await prisma.auditLog.deleteMany();
  await prisma.customerLedger.deleteMany();
  await prisma.sale.deleteMany();
  await prisma.meterReading.deleteMany();
  await prisma.shift.deleteMany();
  await prisma.tankDipReading.deleteMany();
  await prisma.nozzle.deleteMany();
  await prisma.dispenser.deleteMany();
  await prisma.fuelPrice.deleteMany();
  await prisma.tank.deleteMany();
  await prisma.customer.deleteMany();
  await prisma.user.deleteMany();

  // Create users
  const superAdmin = await prisma.user.create({
    data: {
      email: 'admin@pumpos.com',
      phone: '+919000000001',
      passwordHash: await bcrypt.hash('Admin@123', 12),
      name: 'System Administrator',
      role: Role.SUPER_ADMIN,
    },
  });

  const manager = await prisma.user.create({
    data: {
      email: 'manager@pumpos.com',
      phone: '+919000000002',
      passwordHash: await bcrypt.hash('Manager@123', 12),
      name: 'Station Manager',
      role: Role.MANAGER,
    },
  });

  const operator1 = await prisma.user.create({
    data: {
      email: 'operator1@pumpos.com',
      phone: '+919000000003',
      passwordHash: await bcrypt.hash('Operator@123', 12),
      name: 'Ramesh Kumar',
      role: Role.OPERATOR,
    },
  });

  const operator2 = await prisma.user.create({
    data: {
      email: 'operator2@pumpos.com',
      phone: '+919000000004',
      passwordHash: await bcrypt.hash('Operator@123', 12),
      name: 'Suresh Patel',
      role: Role.OPERATOR,
    },
  });

  const accountant = await prisma.user.create({
    data: {
      email: 'accounts@pumpos.com',
      phone: '+919000000005',
      passwordHash: await bcrypt.hash('Accountant@123', 12),
      name: 'Priya Sharma',
      role: Role.ACCOUNTANT,
    },
  });

  console.log(`✅ Created ${5} users`);

  // Create fuel prices
  const fuelPrices = await prisma.fuelPrice.createMany({
    data: [
      { fuelType: FuelType.PETROL_91, buyingPrice: 92.50, sellingPrice: 96.72 },
      { fuelType: FuelType.PETROL_95, buyingPrice: 98.20, sellingPrice: 102.45 },
      { fuelType: FuelType.DIESEL, buyingPrice: 85.30, sellingPrice: 89.62 },
      { fuelType: FuelType.PREMIUM_DIESEL, buyingPrice: 91.00, sellingPrice: 95.50 },
      { fuelType: FuelType.CNG, buyingPrice: 62.00, sellingPrice: 68.50 },
      { fuelType: FuelType.EV_FAST, buyingPrice: 8.50, sellingPrice: 12.00 },
    ],
  });

  console.log(`✅ Created ${fuelPrices.count} fuel prices`);

  // Create tanks
  const tank1 = await prisma.tank.create({
    data: {
      tankNumber: 'T-001',
      fuelType: FuelType.PETROL_91,
      capacityLitres: 20000.00,
      currentStock: 15420.50,
      deadStockLevel: 500.00,
    },
  });

  const tank2 = await prisma.tank.create({
    data: {
      tankNumber: 'T-002',
      fuelType: FuelType.PETROL_95,
      capacityLitres: 15000.00,
      currentStock: 8750.25,
      deadStockLevel: 500.00,
    },
  });

  const tank3 = await prisma.tank.create({
    data: {
      tankNumber: 'T-003',
      fuelType: FuelType.DIESEL,
      capacityLitres: 25000.00,
      currentStock: 18900.00,
      deadStockLevel: 500.00,
    },
  });

  const tank4 = await prisma.tank.create({
    data: {
      tankNumber: 'T-004',
      fuelType: FuelType.CNG,
      capacityLitres: 5000.00,
      currentStock: 3200.00,
      deadStockLevel: 200.00,
    },
  });

  console.log(`✅ Created 4 tanks`);

  // Create dispensers and nozzles
  const dispenser1 = await prisma.dispenser.create({
    data: {
      pumpNumber: 'P-01',
      tankId: tank1.id,
      nozzles: {
        create: [
          { nozzleNumber: 1, fuelType: FuelType.PETROL_91, lastReading: 45230.50 },
          { nozzleNumber: 2, fuelType: FuelType.PETROL_91, lastReading: 38910.25 },
        ],
      },
    },
  });

  const dispenser2 = await prisma.dispenser.create({
    data: {
      pumpNumber: 'P-02',
      tankId: tank2.id,
      nozzles: {
        create: [
          { nozzleNumber: 1, fuelType: FuelType.PETROL_95, lastReading: 21560.00 },
        ],
      },
    },
  });

  const dispenser3 = await prisma.dispenser.create({
    data: {
      pumpNumber: 'P-03',
      tankId: tank3.id,
      nozzles: {
        create: [
          { nozzleNumber: 1, fuelType: FuelType.DIESEL, lastReading: 67890.75 },
          { nozzleNumber: 2, fuelType: FuelType.DIESEL, lastReading: 54320.00 },
        ],
      },
    },
  });

  const dispenser4 = await prisma.dispenser.create({
    data: {
      pumpNumber: 'P-04',
      tankId: tank4.id,
      nozzles: {
        create: [
          { nozzleNumber: 1, fuelType: FuelType.CNG, lastReading: 12500.00 },
        ],
      },
    },
  });

  console.log(`✅ Created 4 dispensers with 6 nozzles`);

  // Create customers
  const customer1 = await prisma.customer.create({
    data: {
      accountName: 'City Logistics Pvt Ltd',
      phone: '+919876543210',
      creditLimit: 500000.00,
      currentBalance: 125000.00,
    },
  });

  const customer2 = await prisma.customer.create({
    data: {
      accountName: 'Metro Transport Corp',
      phone: '+919876543211',
      creditLimit: 300000.00,
      currentBalance: 45000.00,
    },
  });

  const customer3 = await prisma.customer.create({
    data: {
      accountName: 'Green Fleet Services',
      phone: '+919876543212',
      creditLimit: 200000.00,
      currentBalance: 0.00,
    },
  });

  console.log(`✅ Created 3 fleet customers`);

  // Create a sample closed shift
  const shift = await prisma.shift.create({
    data: {
      status: 'CLOSED',
      attendantId: operator1.id,
      managerId: manager.id,
      totalFuelSales: 45250.00,
      cashExpected: 28500.00,
      cashCollected: 28450.00,
      cashShortage: 50.00,
      openedAt: new Date(Date.now() - 86400000),
      closedAt: new Date(Date.now() - 82800000),
      sales: {
        create: [
          { paymentMode: PaymentMode.CASH, amount: 28450.00 },
          { paymentMode: PaymentMode.POS_CARD, amount: 8500.00 },
          { paymentMode: PaymentMode.UPI_QR, amount: 5300.00 },
          { paymentMode: PaymentMode.FLEET_CREDIT, amount: 4000.00, customerId: customer1.id },
        ],
      },
    },
  });

  console.log(`✅ Created sample shift #${shift.shiftNumber}`);

  console.log('\n🎉 Seed completed successfully!');
  console.log('\nDefault credentials:');
  console.log('  Admin:    admin@pumpos.com / Admin@123');
  console.log('  Manager:  manager@pumpos.com / Manager@123');
  console.log('  Operator: operator1@pumpos.com / Operator@123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
