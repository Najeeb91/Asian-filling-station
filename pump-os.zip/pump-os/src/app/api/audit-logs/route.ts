import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { AuditService } from '@/services/audit.service';
import { prisma } from '@/lib/prisma';
import { ApiResponse } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    // Only managers and above can view audit logs
    if (!['SUPER_ADMIN', 'MANAGER', 'ACCOUNTANT'].includes(session.user.role)) {
      return Response.json({ success: false, error: 'Forbidden' } as ApiResponse, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action') || undefined;
    const resource = searchParams.get('resource') || undefined;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const result = await AuditService.query(prisma, {
      action: action || undefined,
      resource: resource || undefined,
      page,
      limit,
    });

    return Response.json({
      success: true,
      data: result.logs,
      pagination: result.pagination,
    } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch audit logs';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
