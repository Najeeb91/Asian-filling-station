import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { BackupService } from '@/services/backup.service';
import { AuditService } from '@/services/audit.service';
import { ApiResponse } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    if (!['SUPER_ADMIN', 'MANAGER'].includes(session.user.role)) {
      return Response.json({ success: false, error: 'Forbidden' } as ApiResponse, { status: 403 });
    }

    const backupService = new BackupService();
    const result = await backupService.createBackup();

    if (result.success) {
      await AuditService.log(
        prisma,
        session.user.id,
        'BACKUP_CREATED',
        'Backup',
        undefined,
        null,
        { objectKey: result.objectKey, size: result.size }
      );
    }

    return Response.json({ success: result.success, data: result } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Backup failed';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
