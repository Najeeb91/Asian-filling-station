import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { createCustomerSchema } from '@/lib/validators';
import { AuditService } from '@/services/audit.service';
import { ApiResponse } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where = search
      ? {
          OR: [
            { accountName: { contains: search, mode: 'insensitive' as const } },
            { phone: { contains: search } },
          ],
        }
      : {};

    const [customers, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        include: { _count: { select: { sales: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.customer.count({ where }),
    ]);

    return Response.json({
      success: true,
      data: customers,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch customers';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const body = await req.json();
    const parsed = createCustomerSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json(
        { success: false, error: 'Validation failed', message: parsed.error.format() } as ApiResponse,
        { status: 400 }
      );
    }

    const customer = await prisma.customer.create({
      data: {
        accountName: parsed.data.accountName,
        phone: parsed.data.phone,
        creditLimit: parsed.data.creditLimit,
      },
    });

    await AuditService.log(
      prisma,
      session.user.id,
      'CUSTOMER_CREATED',
      'Customer',
      customer.id,
      null,
      { accountName: parsed.data.accountName, phone: parsed.data.phone }
    );

    return Response.json({ success: true, data: customer } as ApiResponse, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create customer';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
