import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { updateFuelPriceSchema } from '@/lib/validators';
import { AuditService } from '@/services/audit.service';
import { ApiResponse } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const prices = await prisma.fuelPrice.findMany({
      where: { isActive: true },
      orderBy: { fuelType: 'asc' },
    });

    return Response.json({ success: true, data: prices } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch fuel prices';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    // Only managers and above can update prices
    if (!['SUPER_ADMIN', 'MANAGER'].includes(session.user.role)) {
      return Response.json({ success: false, error: 'Forbidden' } as ApiResponse, { status: 403 });
    }

    const body = await req.json();
    const parsed = updateFuelPriceSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json(
        { success: false, error: 'Validation failed', message: parsed.error.format() } as ApiResponse,
        { status: 400 }
      );
    }

    // Deactivate old price
    await prisma.fuelPrice.updateMany({
      where: { fuelType: parsed.data.fuelType, isActive: true },
      data: { isActive: false, effectiveTo: new Date() },
    });

    // Create new price
    const price = await prisma.fuelPrice.create({
      data: {
        fuelType: parsed.data.fuelType,
        buyingPrice: parsed.data.buyingPrice,
        sellingPrice: parsed.data.sellingPrice,
      },
    });

    await AuditService.log(
      prisma,
      session.user.id,
      'FUEL_PRICE_UPDATED',
      'FuelPrice',
      price.id,
      null,
      { fuelType: parsed.data.fuelType, sellingPrice: parsed.data.sellingPrice }
    );

    return Response.json({ success: true, data: price } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to update fuel price';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
