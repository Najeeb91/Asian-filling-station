import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { createSaleSchema } from '@/lib/validators';
import { AuditService } from '@/services/audit.service';
import { ApiResponse } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const shiftId = searchParams.get('shiftId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where = shiftId ? { shiftId } : {};

    const [sales, total] = await Promise.all([
      prisma.sale.findMany({
        where,
        include: { customer: true, shift: { select: { shiftNumber: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.sale.count({ where }),
    ]);

    return Response.json({
      success: true,
      data: sales,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch sales';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const body = await req.json();
    const parsed = createSaleSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json(
        { success: false, error: 'Validation failed', message: parsed.error.format() } as ApiResponse,
        { status: 400 }
      );
    }

    const shift = await prisma.shift.findUnique({
      where: { id: parsed.data.shiftId },
    });

    if (!shift || shift.status !== 'OPEN') {
      return Response.json(
        { success: false, error: 'Shift not found or not open' } as ApiResponse,
        { status: 400 }
      );
    }

    const sale = await prisma.sale.create({
      data: {
        shiftId: parsed.data.shiftId,
        paymentMode: parsed.data.paymentMode,
        amount: parsed.data.amount,
        customerId: parsed.data.customerId || null,
        description: parsed.data.description || null,
      },
    });

    await AuditService.log(
      prisma,
      session.user.id,
      'SALE_CREATED',
      'Sale',
      sale.id,
      null,
      { amount: parsed.data.amount, paymentMode: parsed.data.paymentMode }
    );

    return Response.json({ success: true, data: sale } as ApiResponse, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create sale';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
