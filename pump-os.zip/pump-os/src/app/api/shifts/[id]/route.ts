import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { ShiftReconciliationService } from '@/services/shiftReconciliation.service';
import { ApiResponse } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const summary = await ShiftReconciliationService.getShiftSummary(prisma, params.id);

    if (!summary) {
      return Response.json({ success: false, error: 'Shift not found' } as ApiResponse, { status: 404 });
    }

    return Response.json({ success: true, data: summary } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch shift';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}
