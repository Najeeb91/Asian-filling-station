import { NextRequest } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { closeShiftSchema } from '@/lib/validators';
import { ShiftReconciliationService } from '@/services/shiftReconciliation.service';
import { AuditService } from '@/services/audit.service';
import { ApiResponse } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where = status ? { status } : {};

    const [shifts, total] = await Promise.all([
      prisma.shift.findMany({
        where,
        include: {
          attendant: { select: { name: true, email: true } },
          manager: { select: { name: true, email: true } },
          _count: { select: { sales: true, meterReadings: true } },
        },
        orderBy: { openedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.shift.count({ where }),
    ]);

    return Response.json({
      success: true,
      data: shifts,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to fetch shifts';
    return Response.json({ success: false, error: message } as ApiResponse, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return Response.json({ success: false, error: 'Unauthorized' } as ApiResponse, { status: 401 });
    }

    const body = await req.json();
    const parsed = closeShiftSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json(
        { success: false, error: 'Validation failed', message: parsed.error.format() } as ApiResponse,
        { status: 400 }
      );
    }

    const ip = req.headers.get('x-forwarded-for') || req.ip || undefined;
    const userAgent = req.headers.get('user-agent') || undefined;

    const result = await ShiftReconciliationService.reconcileAndCloseShift(
      prisma,
      parsed.data,
      ip,
      userAgent
    );

    return Response.json({ success: true, data: result } as ApiResponse);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to close shift';
    const status = message.includes('not found') ? 404 : message.includes('Invalid') || message.includes('detected') || message.includes('exceeded') ? 400 : 500;
    return Response.json({ success: false, error: message } as ApiResponse, { status });
  }
}
