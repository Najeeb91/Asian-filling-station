import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { DashboardStats } from '@/types';
import StatsCard from '@/components/dashboard/StatsCard';
import RecentShifts from '@/components/dashboard/RecentShifts';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { Fuel, TrendingUp, AlertTriangle, Clock } from 'lucide-react';

async function getDashboardStats(): Promise<DashboardStats> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [
    totalShiftsToday,
    totalRevenueToday,
    totalVolumeToday,
    activeShifts,
    flaggedShifts,
    lowStockTanks,
  ] = await Promise.all([
    prisma.shift.count({
      where: { openedAt: { gte: today } },
    }),
    prisma.shift.aggregate({
      where: { openedAt: { gte: today }, status: 'CLOSED' },
      _sum: { totalFuelSales: true },
    }),
    prisma.meterReading.aggregate({
      where: { createdAt: { gte: today } },
      _sum: { netSoldVolume: true },
    }),
    prisma.shift.count({
      where: { status: 'OPEN' },
    }),
    prisma.shift.count({
      where: { status: 'DISCREPANCY_FLAGGED' },
    }),
    prisma.tank.count({
      where: {
        currentStock: {
          lte: prisma.tank.fields.deadStockLevel,
        },
      },
    }),
  ]);

  return {
    totalShiftsToday,
    totalRevenueToday: formatCurrency(totalRevenueToday._sum.totalFuelSales || 0),
    totalVolumeToday: formatNumber(totalVolumeToday._sum.netSoldVolume || 0, 2),
    activeShifts,
    flaggedShifts,
    lowStockTanks,
  };
}

async function getRecentShifts() {
  return prisma.shift.findMany({
    take: 5,
    orderBy: { openedAt: 'desc' },
    include: {
      attendant: { select: { name: true } },
      manager: { select: { name: true } },
      _count: { select: { sales: true, meterReadings: true } },
    },
  });
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    redirect('/login');
  }

  const stats = await getDashboardStats();
  const recentShifts = await getRecentShifts();

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center">
              <Fuel className="w-5 h-5 text-brand-500" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">PumpOS</h1>
              <p className="text-xs text-slate-400">Station Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">
              Welcome, <span className="text-slate-200 font-medium">{session.user.name}</span>
            </span>
            <div className="px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-xs font-medium text-brand-400">
              {session.user.role}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <StatsCard
            title="Today's Revenue"
            value={stats.totalRevenueToday}
            icon={<TrendingUp className="w-5 h-5" />}
            color="brand"
          />
          <StatsCard
            title="Volume Sold Today"
            value={`${stats.totalVolumeToday} L`}
            icon={<Fuel className="w-5 h-5" />}
            color="success"
          />
          <StatsCard
            title="Shifts Today"
            value={stats.totalShiftsToday.toString()}
            icon={<Clock className="w-5 h-5" />}
            color="slate"
          />
          <StatsCard
            title="Active Shifts"
            value={stats.activeShifts.toString()}
            icon={<Clock className="w-5 h-5" />}
            color="warning"
          />
          <StatsCard
            title="Flagged Shifts"
            value={stats.flaggedShifts.toString()}
            icon={<AlertTriangle className="w-5 h-5" />}
            color="danger"
            alert={stats.flaggedShifts > 0}
          />
          <StatsCard
            title="Low Stock Tanks"
            value={stats.lowStockTanks.toString()}
            icon={<Fuel className="w-5 h-5" />}
            color="danger"
            alert={stats.lowStockTanks > 0}
          />
        </div>

        {/* Recent Shifts */}
        <div className="glass-panel">
          <div className="p-6 border-b border-slate-800">
            <h2 className="text-lg font-semibold text-white">Recent Shifts</h2>
            <p className="text-sm text-slate-400 mt-1">Latest shift activity across all pumps</p>
          </div>
          <RecentShifts shifts={recentShifts} />
        </div>
      </main>
    </div>
  );
}
