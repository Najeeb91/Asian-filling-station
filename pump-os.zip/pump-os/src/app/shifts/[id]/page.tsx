import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { formatCurrency, formatDate, formatNumber } from '@/lib/utils';
import { Badge } from '@/components/ui/Badge';
import Link from 'next/link';
import { ArrowLeft, Fuel, Droplets, CreditCard, AlertTriangle } from 'lucide-react';

export default async function ShiftDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect('/login');

  const shift = await prisma.shift.findUnique({
    where: { id: params.id },
    include: {
      attendant: { select: { name: true, email: true } },
      manager: { select: { name: true, email: true } },
      meterReadings: {
        include: {
          nozzle: { include: { dispenser: true } },
        },
      },
      sales: {
        include: { customer: true },
        orderBy: { createdAt: 'desc' },
      },
    },
  });

  if (!shift) redirect('/shifts');

  const paymentBreakdown = await prisma.sale.groupBy({
    by: ['paymentMode'],
    where: { shiftId: shift.id },
    _sum: { amount: true },
  });

  const totalVolume = shift.meterReadings.reduce(
    (sum, r) => sum + Number(r.netSoldVolume), 0
  );

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link href="/shifts" className="text-slate-400 hover:text-white transition-colors p-2 hover:bg-slate-800 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-white">Shift #{shift.shiftNumber}</h1>
            <p className="text-sm text-slate-400">Opened {formatDate(shift.openedAt)}</p>
          </div>
          <Badge variant={
            shift.status === 'CLOSED' ? 'success' :
            shift.status === 'DISCREPANCY_FLAGGED' ? 'danger' : 'default'
          } className="ml-auto">
            {shift.status.replace(/_/g, ' ')}
          </Badge>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <Fuel className="w-4 h-4 text-brand-400" />
              <p className="text-xs text-slate-400 uppercase font-semibold">Revenue</p>
            </div>
            <p className="text-2xl font-bold text-white">{formatCurrency(shift.totalFuelSales)}</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <Droplets className="w-4 h-4 text-success-400" />
              <p className="text-xs text-slate-400 uppercase font-semibold">Volume</p>
            </div>
            <p className="text-2xl font-bold text-white">{formatNumber(totalVolume)} L</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className="w-4 h-4 text-warning-400" />
              <p className="text-xs text-slate-400 uppercase font-semibold">Cash Collected</p>
            </div>
            <p className="text-2xl font-bold text-white">{formatCurrency(shift.cashCollected)}</p>
          </div>
          <div className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className={`w-4 h-4 ${Number(shift.cashShortage) > 0 ? 'text-danger-400' : 'text-success-400'}`} />
              <p className="text-xs text-slate-400 uppercase font-semibold">Shortage</p>
            </div>
            <p className={`text-2xl font-bold ${Number(shift.cashShortage) > 0 ? 'text-danger-400' : 'text-success-400'}`}>
              {formatCurrency(shift.cashShortage)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Meter Readings */}
          <div className="glass-panel">
            <div className="p-6 border-b border-slate-800">
              <h2 className="text-lg font-semibold text-white">Meter Readings</h2>
              <p className="text-sm text-slate-400 mt-1">Per-nozzle volume and revenue</p>
            </div>
            <div className="divide-y divide-slate-800">
              {shift.meterReadings.length === 0 && (
                <div className="p-6 text-slate-500 text-sm">No meter readings recorded</div>
              )}
              {shift.meterReadings.map((reading) => (
                <div key={reading.id} className="p-5 flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium text-sm">
                      Pump {reading.nozzle.dispenser.pumpNumber} · Nozzle {reading.nozzle.nozzleNumber}
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      {formatNumber(reading.openingReading)} → {formatNumber(reading.closingReading)}
                      {Number(reading.testingVolume) > 0 && (
                        <span className="text-warning-400 ml-2">(test: {formatNumber(reading.testingVolume)} L)</span>
                      )}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">{formatNumber(reading.netSoldVolume)} L</p>
                    <p className="text-sm text-slate-400">{formatCurrency(reading.totalAmount)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Breakdown */}
          <div className="glass-panel">
            <div className="p-6 border-b border-slate-800">
              <h2 className="text-lg font-semibold text-white">Payment Breakdown</h2>
              <p className="text-sm text-slate-400 mt-1">Revenue by payment mode</p>
            </div>
            <div className="divide-y divide-slate-800">
              {paymentBreakdown.length === 0 && (
                <div className="p-6 text-slate-500 text-sm">No payments recorded</div>
              )}
              {paymentBreakdown.map((pb) => (
                <div key={pb.paymentMode} className="p-5 flex items-center justify-between">
                  <p className="text-slate-300 text-sm">{pb.paymentMode.replace(/_/g, ' ')}</p>
                  <p className="text-white font-medium">{formatCurrency(pb._sum.amount || 0)}</p>
                </div>
              ))}
              <div className="p-5 flex items-center justify-between bg-slate-800/30">
                <p className="text-white font-semibold">Total</p>
                <p className="text-white font-bold text-lg">{formatCurrency(shift.totalFuelSales)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sales Detail */}
        <div className="glass-panel">
          <div className="p-6 border-b border-slate-800">
            <h2 className="text-lg font-semibold text-white">Transaction Log</h2>
          </div>
          <div className="divide-y divide-slate-800">
            {shift.sales.length === 0 && (
              <div className="p-6 text-slate-500 text-sm">No transactions</div>
            )}
            {shift.sales.map((sale) => (
              <div key={sale.id} className="p-5 flex items-center justify-between">
                <div>
                  <p className="text-white text-sm font-medium">{sale.paymentMode.replace(/_/g, ' ')}</p>
                  {sale.customer && (
                    <p className="text-xs text-slate-400 mt-0.5">{sale.customer.accountName}</p>
                  )}
                </div>
                <p className="text-white font-medium">{formatCurrency(sale.amount)}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
