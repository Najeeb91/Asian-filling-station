'use client';

import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { formatDate, formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/Badge';
import { Fuel, Plus, ArrowRight, Loader2 } from 'lucide-react';

export default function ShiftsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['shifts'],
    queryFn: async () => {
      const res = await fetch('/api/shifts');
      if (!res.ok) throw new Error('Failed to fetch shifts');
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
      </div>
    );
  }

  const shifts = data?.data || [];

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Fuel className="w-6 h-6 text-brand-500" />
            <h1 className="text-xl font-bold text-white">All Shifts</h1>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg transition-colors text-sm font-medium">
            <Plus className="w-4 h-4" />
            New Shift
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="glass-panel overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-800/50 text-xs uppercase text-slate-400 font-semibold">
              <tr>
                <th className="px-6 py-4">Shift #</th>
                <th className="px-6 py-4">Attendant</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Revenue</th>
                <th className="px-6 py-4">Opened</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {shifts.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                    No shifts recorded yet
                  </td>
                </tr>
              )}
              {shifts.map((shift: any) => (
                <tr key={shift.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-white">#{shift.shiftNumber}</td>
                  <td className="px-6 py-4 text-slate-300">{shift.attendant?.name || '—'}</td>
                  <td className="px-6 py-4">
                    <Badge variant={
                      shift.status === 'CLOSED' ? 'success' :
                      shift.status === 'OPEN' ? 'default' :
                      shift.status === 'DISCREPANCY_FLAGGED' ? 'danger' : 'warning'
                    }>
                      {shift.status.replace(/_/g, ' ')}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-slate-300">
                    {shift.totalFuelSales ? formatCurrency(shift.totalFuelSales) : '—'}
                  </td>
                  <td className="px-6 py-4 text-slate-400 text-sm">
                    {formatDate(shift.openedAt)}
                  </td>
                  <td className="px-6 py-4">
                    <Link
                      href={`/shifts/${shift.id}`}
                      className="text-brand-400 hover:text-brand-300 transition-colors inline-flex items-center gap-1"
                    >
                      View <ArrowRight className="w-3 h-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
