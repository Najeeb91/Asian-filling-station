'use client';

import { ShiftStatus } from '@prisma/client';
import { formatDate, formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/Badge';
import Link from 'next/link';

interface Shift {
  id: string;
  shiftNumber: number;
  status: ShiftStatus;
  openedAt: Date;
  closedAt: Date | null;
  totalFuelSales: string | null;
  cashCollected: string | null;
  attendant: { name: string };
  manager: { name: string } | null;
  _count: { sales: number; meterReadings: number };
}

interface RecentShiftsProps {
  shifts: Shift[];
}

const statusConfig: Record<ShiftStatus, { label: string; variant: 'default' | 'success' | 'warning' | 'danger' }> = {
  OPEN: { label: 'Open', variant: 'default' },
  PENDING_RECONCILIATION: { label: 'Pending', variant: 'warning' },
  CLOSED: { label: 'Closed', variant: 'success' },
  DISCREPANCY_FLAGGED: { label: 'Discrepancy', variant: 'danger' },
};

export default function RecentShifts({ shifts }: RecentShiftsProps) {
  if (shifts.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500">
        No shifts recorded yet
      </div>
    );
  }

  return (
    <div className="divide-y divide-slate-800">
      {shifts.map((shift) => (
        <Link
          key={shift.id}
          href={`/shifts/${shift.id}`}
          className="flex items-center justify-between p-4 hover:bg-slate-800/30 transition-colors"
        >
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-sm font-bold text-slate-300">
              #{shift.shiftNumber}
            </div>
            <div>
              <p className="text-sm font-medium text-white">
                {shift.attendant.name}
              </p>
              <p className="text-xs text-slate-500">
                {formatDate(shift.openedAt)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">
                {shift.totalFuelSales ? formatCurrency(shift.totalFuelSales) : '—'}
              </p>
              <p className="text-xs text-slate-500">
                {shift._count.sales} sales · {shift._count.meterReadings} readings
              </p>
            </div>
            <Badge variant={statusConfig[shift.status].variant}>
              {statusConfig[shift.status].label}
            </Badge>
          </div>
        </Link>
      ))}
    </div>
  );
}
