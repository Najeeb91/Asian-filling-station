'use client';

import { cn } from '@/lib/utils';

interface StatsCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: 'brand' | 'success' | 'warning' | 'danger' | 'slate';
  alert?: boolean;
}

const colorMap = {
  brand: 'text-brand-400 border-brand-500/20 after:bg-brand-500',
  success: 'text-success-400 border-success-500/20 after:bg-success-500',
  warning: 'text-warning-400 border-warning-500/20 after:bg-warning-500',
  danger: 'text-danger-400 border-danger-500/20 after:bg-danger-500',
  slate: 'text-slate-400 border-slate-500/20 after:bg-slate-500',
};

export default function StatsCard({ title, value, icon, color, alert }: StatsCardProps) {
  return (
    <div
      className={cn(
        'stat-card',
        colorMap[color],
        alert && 'animate-pulse-slow'
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-400 mb-1">{title}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
        </div>
        <div className={cn('p-2 rounded-lg bg-current/10', colorMap[color].split(' ')[0])}>
          {icon}
        </div>
      </div>
    </div>
  );
}
