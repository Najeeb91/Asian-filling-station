import twilio from 'twilio';
import pino from 'pino';

const logger = pino({ name: 'notifications' });

class NotificationService {
  private client: twilio.Twilio | null = null;
  private fromNumber: string | null = null;
  private managerNumber: string | null = null;
  private enabled = false;

  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const fromNumber = process.env.TWILIO_PHONE_NUMBER;
    const managerNumber = process.env.MANAGER_ALERT_PHONE;

    if (accountSid && authToken && fromNumber) {
      this.client = twilio(accountSid, authToken);
      this.fromNumber = fromNumber;
      this.managerNumber = managerNumber || null;
      this.enabled = true;
    } else {
      logger.warn('Twilio not configured. SMS notifications disabled.');
    }
  }

  async sendSMS(to: string, body: string): Promise<boolean> {
    if (!this.enabled || !this.client || !this.fromNumber) {
      logger.info({ to, body }, 'SMS suppressed (Twilio not configured)');
      return false;
    }

    try {
      await this.client.messages.create({
        body,
        from: this.fromNumber,
        to,
      });
      logger.info({ to }, 'SMS sent successfully');
      return true;
    } catch (error) {
      logger.error({ error, to }, 'Failed to send SMS');
      return false;
    }
  }

  async alertManager(message: string): Promise<boolean> {
    if (!this.managerNumber) {
      logger.warn('Manager alert phone not configured');
      return false;
    }
    return this.sendSMS(this.managerNumber, `🚨 PumpOS Alert: ${message}`);
  }

  async alertDiscrepancy(shiftNumber: number, discrepancy: string): Promise<boolean> {
    return this.alertManager(
      `Shift #${shiftNumber} has cash discrepancy of ${discrepancy}. Immediate review required.`
    );
  }

  async alertLowStock(tankNumber: string, fuelType: string, currentStock: string): Promise<boolean> {
    return this.alertManager(
      `Tank ${tankNumber} (${fuelType}) is running low. Current stock: ${currentStock}L`
    );
  }
}

export const notificationService = new NotificationService();
