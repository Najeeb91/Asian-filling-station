import { z } from 'zod';
import { FuelType, PaymentMode, Role } from '@prisma/client';

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const nozzleReadingSchema = z.object({
  nozzleId: z.string().uuid(),
  closingReading: z.coerce.number().positive('Closing reading must be positive'),
  testingVolume: z.coerce.number().min(0).default(0),
});

export const paymentSchema = z.object({
  paymentMode: z.nativeEnum(PaymentMode),
  amount: z.coerce.number().positive('Amount must be positive'),
  customerId: z.string().uuid().optional(),
});

export const closeShiftSchema = z.object({
  shiftId: z.string().uuid(),
  managerId: z.string().uuid(),
  nozzleReadings: z.array(nozzleReadingSchema).min(1, 'At least one nozzle reading required'),
  payments: z.array(paymentSchema),
  cashCollected: z.coerce.number().min(0, 'Cash collected cannot be negative'),
  notes: z.string().max(500).optional(),
});

export type CloseShiftInput = z.infer<typeof closeShiftSchema>;

export const createSaleSchema = z.object({
  shiftId: z.string().uuid(),
  paymentMode: z.nativeEnum(PaymentMode),
  amount: z.coerce.number().positive(),
  customerId: z.string().uuid().optional(),
  description: z.string().max(200).optional(),
});

export const createCustomerSchema = z.object({
  accountName: z.string().min(2).max(100),
  phone: z.string().regex(/^\+?[1-9]\d{9,14}$/, 'Invalid phone number'),
  creditLimit: z.coerce.number().min(0).default(0),
});

export const updateFuelPriceSchema = z.object({
  fuelType: z.nativeEnum(FuelType),
  buyingPrice: z.coerce.number().positive(),
  sellingPrice: z.coerce.number().positive(),
});

export const meterReadingQuerySchema = z.object({
  shiftId: z.string().uuid().optional(),
  nozzleId: z.string().uuid().optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
});
