import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const path = req.nextUrl.pathname;

    // Role-based access control
    if (path.startsWith('/api/admin') || path.startsWith('/admin')) {
      if (token?.role !== 'SUPER_ADMIN') {
        return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      }
    }

    if (path.startsWith('/api/manager') || path.startsWith('/manager')) {
      if (!['SUPER_ADMIN', 'MANAGER'].includes(token?.role as string)) {
        return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
      }
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      authorized({ req, token }) {
        // Allow auth callbacks
        if (req.nextUrl.pathname.startsWith('/api/auth')) return true;
        // Allow public assets
        if (req.nextUrl.pathname.startsWith('/_next')) return true;
        if (req.nextUrl.pathname === '/login') return true;
        // Require auth for everything else
        return !!token;
      },
    },
    pages: {
      signIn: '/login',
    },
  }
);

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
