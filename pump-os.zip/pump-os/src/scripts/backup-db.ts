import { BackupService } from '@/services/backup.service';

async function main() {
  console.log('🔒 PumpOS Encrypted Backup');
  console.log('═══════════════════════════════════════');

  const service = new BackupService();
  const result = await service.createBackup();

  if (result.success) {
    console.log(`✅ Backup completed: ${result.objectKey}`);
    console.log(`   Size: ${((result.size || 0) / 1024 / 1024).toFixed(2)} MB`);
    console.log(`   Duration: ${result.durationMs}ms`);
    process.exit(0);
  } else {
    console.error(`❌ Backup failed: ${result.error}`);
    process.exit(1);
  }
}

main();
