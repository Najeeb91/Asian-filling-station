import { createDecipheriv, scryptSync } from 'crypto';
import { createGunzip } from 'zlib';
import { spawn } from 'child_process';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { Readable } from 'stream';

async function runRestore(objectKey: string) {
  const { DATABASE_URL, BACKUP_ENCRYPTION_KEY, S3_BUCKET_NAME, S3_REGION, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY } = process.env;

  if (!DATABASE_URL || !BACKUP_ENCRYPTION_KEY) {
    throw new Error('DATABASE_URL and BACKUP_ENCRYPTION_KEY required');
  }

  const s3Client = new S3Client({
    region: S3_REGION || 'us-east-1',
    credentials: S3_ACCESS_KEY_ID && S3_SECRET_ACCESS_KEY
      ? { accessKeyId: S3_ACCESS_KEY_ID, secretAccessKey: S3_SECRET_ACCESS_KEY }
      : undefined,
  });

  console.log(`📥 Downloading ${objectKey}...`);

  const response = await s3Client.send(new GetObjectCommand({
    Bucket: S3_BUCKET_NAME || 'station-backups',
    Key: objectKey,
  }));

  if (!response.Body) throw new Error('Empty response from S3');

  const stream = response.Body as Readable;
  const chunks: Buffer[] = [];
  for await (const chunk of stream) chunks.push(chunk);
  const encrypted = Buffer.concat(chunks);

  const salt = encrypted.subarray(0, 16);
  const iv = encrypted.subarray(16, 32);
  const ciphertext = encrypted.subarray(32);

  const key = scryptSync(BACKUP_ENCRYPTION_KEY, salt, 32);
  const decipher = createDecipheriv('aes-256-cbc', key, iv);

  const psql = spawn('psql', ['--dbname', DATABASE_URL], {
    stdio: ['pipe', 'inherit', 'inherit'],
  });

  const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  const gunzip = createGunzip();
  gunzip.write(decrypted);
  gunzip.pipe(psql.stdin);

  await new Promise<void>((resolve, reject) => {
    psql.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`psql exited with code ${code}`));
    });
  });

  console.log('✅ Restore completed successfully');
}

const objectKey = process.argv[2];
if (!objectKey) {
  console.error('Usage: npm run restore -- backups/2024-01-01T00-00-00_pump_backup.sql.gz.enc');
  process.exit(1);
}

runRestore(objectKey).catch((err) => {
  console.error('❌ Restore failed:', err.message);
  process.exit(1);
});
