import { PrismaClient, Prisma } from '@prisma/client';
import pino from 'pino';

const logger = pino({ name: 'audit-service' });

export class AuditService {
  static async log(
    prisma: PrismaClient | Prisma.TransactionClient,
    userId: string,
    action: string,
    resource: string,
    recordId?: string,
    oldValue?: Record<string, unknown> | null,
    newValue?: Record<string, unknown> | null,
    ipAddress?: string,
    userAgent?: string
  ) {
    try {
      await prisma.auditLog.create({
        data: {
          userId,
          action,
          resource,
          recordId: recordId || null,
          oldValue: oldValue || null,
          newValue: newValue || null,
          ipAddress: ipAddress || null,
          userAgent: userAgent || null,
        },
      });
    } catch (error) {
      logger.error({ error, userId, action }, 'Failed to create audit log');
      // Don't throw - audit logging should not break business logic
    }
  }

  static async query(
    prisma: PrismaClient,
    params: {
      userId?: string;
      action?: string;
      resource?: string;
      from?: Date;
      to?: Date;
      page?: number;
      limit?: number;
    }
  ) {
    const { userId, action, resource, from, to, page = 1, limit = 20 } = params;

    const where: Prisma.AuditLogWhereInput = {};
    if (userId) where.userId = userId;
    if (action) where.action = action;
    if (resource) where.resource = resource;
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = from;
      if (to) where.createdAt.lte = to;
    }

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        include: { user: { select: { name: true, email: true, role: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.auditLog.count({ where }),
    ]);

    return {
      logs,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }
}
