import { spawn } from 'child_process';
import { createCipheriv, randomBytes, scryptSync } from 'crypto';
import { PassThrough } from 'stream';
import { S3Client } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';
import pino from 'pino';
import { promisify } from 'util';
import { exec } from 'child_process';

const logger = pino({ name: 'backup-service' });
const execAsync = promisify(exec);

export interface BackupResult {
  success: boolean;
  objectKey?: string;
  size?: number;
  durationMs?: number;
  error?: string;
}

export class BackupService {
  private s3Client: S3Client;
  private bucketName: string;
  private encryptionKey: string;

  constructor() {
    const region = process.env.S3_REGION || 'us-east-1';
    const accessKeyId = process.env.S3_ACCESS_KEY_ID;
    const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;
    this.bucketName = process.env.S3_BUCKET_NAME || 'station-backups';
    this.encryptionKey = process.env.BACKUP_ENCRYPTION_KEY || '';

    if (!this.encryptionKey || this.encryptionKey.length !== 64) {
      throw new Error('BACKUP_ENCRYPTION_KEY must be exactly 64 hex characters (256 bits)');
    }

    this.s3Client = new S3Client({
      region,
      credentials:
        accessKeyId && secretAccessKey
          ? { accessKeyId, secretAccessKey }
          : undefined,
    });
  }

  async createBackup(): Promise<BackupResult> {
    const startTime = Date.now();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const s3ObjectKey = `backups/${timestamp}_pump_backup.sql.gz.enc`;

    logger.info({ objectKey: s3ObjectKey }, 'Starting encrypted backup');

    try {
      const databaseUrl = process.env.DATABASE_URL;
      if (!databaseUrl) {
        throw new Error('DATABASE_URL not configured');
      }

      // Verify pg_dump availability
      await execAsync('pg_dump --version');

      const salt = randomBytes(16);
      const derivedKey = scryptSync(this.encryptionKey, salt, 32);
      const iv = randomBytes(16);
      const cipher = createCipheriv('aes-256-cbc', derivedKey, iv);

      const pgDump = spawn('pg_dump', [
        '--dbname', databaseUrl,
        '--format', 'plain',
        '--compress', '6',
        '--no-owner',
        '--no-acl',
        '--clean',
        '--if-exists',
      ]);

      const uploadStream = new PassThrough();
      uploadStream.write(salt);
      uploadStream.write(iv);

      let byteCount = 0;
      uploadStream.on('data', (chunk: Buffer) => {
        byteCount += chunk.length;
      });

      pgDump.stdout.pipe(cipher).pipe(uploadStream);

      const parallelUpload = new Upload({
        client: this.s3Client,
        params: {
          Bucket: this.bucketName,
          Key: s3ObjectKey,
          Body: uploadStream,
          ContentType: 'application/octet-stream',
          Metadata: {
            'backup-timestamp': timestamp,
            'backup-version': '1.0',
            'encryption': 'aes-256-cbc',
          },
        },
        queueSize: 4,
        partSize: 5 * 1024 * 1024, // 5MB
      });

      await parallelUpload.done();
      const durationMs = Date.now() - startTime;

      logger.info(
        { objectKey: s3ObjectKey, size: byteCount, durationMs },
        'Backup completed successfully'
      );

      return {
        success: true,
        objectKey: s3ObjectKey,
        size: byteCount,
        durationMs,
      };
    } catch (error) {
      const durationMs = Date.now() - startTime;
      const message = error instanceof Error ? error.message : 'Unknown error';
      logger.error({ error: message, durationMs }, 'Backup failed');

      return {
        success: false,
        error: message,
        durationMs,
      };
    }
  }

  async verifyBackup(objectKey: string): Promise<boolean> {
    try {
      logger.info({ objectKey }, 'Verifying backup existence');
      const { HeadObjectCommand } = await import('@aws-sdk/client-s3');
      await this.s3Client.send(
        new HeadObjectCommand({
          Bucket: this.bucketName,
          Key: objectKey,
        })
      );
      return true;
    } catch {
      return false;
    }
  }
}
