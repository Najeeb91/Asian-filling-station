import { PrismaClient, ShiftStatus, PaymentMode, LedgerEntryType, Prisma } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';
import pino from 'pino';
import { notificationService } from '@/lib/notifications';
import { AuditService } from './audit.service';

const logger = pino({ name: 'shift-reconciliation' });

export interface NozzleReadingInput {
  nozzleId: string;
  closingReading: number;
  testingVolume?: number;
}

export interface PaymentInput {
  paymentMode: PaymentMode;
  amount: number;
  customerId?: string;
}

export interface ReconcilePayload {
  shiftId: string;
  managerId: string;
  nozzleReadings: NozzleReadingInput[];
  payments: PaymentInput[];
  cashCollected: number;
  notes?: string;
}

export interface ReconcileResult {
  shiftId: string;
  shiftNumber: number;
  totalGrossRevenue: string;
  totalVolumeSold: string;
  cashExpected: string;
  cashCollected: string;
  cashDiscrepancy: string;
  status: ShiftStatus;
  discrepancyFlagged: boolean;
}

export class ShiftReconciliationError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'ShiftReconciliationError';
  }
}

export class ShiftReconciliationService {
  private static readonly DISCREPANCY_THRESHOLD = new Decimal(5.0);
  private static readonly MINIMUM_CASH_TOLERANCE = new Decimal(0.01);

  public static async reconcileAndCloseShift(
    prisma: PrismaClient,
    payload: ReconcilePayload,
    ipAddress?: string,
    userAgent?: string
  ): Promise<ReconcileResult> {
    const { shiftId, managerId, nozzleReadings, payments, cashCollected, notes } = payload;
    const actualCash = new Decimal(cashCollected);

    logger.info({ shiftId, managerId, nozzleCount: nozzleReadings.length }, 'Starting shift reconciliation');

    return await prisma.$transaction(
      async (tx) => {
        // 1. Validate shift state
        const shift = await tx.shift.findUnique({
          where: { id: shiftId },
          include: { attendant: true },
        });

        if (!shift) {
          throw new ShiftReconciliationError('Shift not found', 'SHIFT_NOT_FOUND', { shiftId });
        }

        if (shift.status !== ShiftStatus.OPEN && shift.status !== ShiftStatus.PENDING_RECONCILIATION) {
          throw new ShiftReconciliationError(
            `Shift cannot be reconciled. Current status: ${shift.status}`,
            'INVALID_SHIFT_STATUS',
            { shiftId, currentStatus: shift.status }
          );
        }

        // 2. Validate manager
        const manager = await tx.user.findUnique({ where: { id: managerId } });
        if (!manager || !manager.isActive) {
          throw new ShiftReconciliationError('Invalid manager', 'INVALID_MANAGER', { managerId });
        }

        // 3. Process nozzle readings
        let totalGrossRevenue = new Decimal(0);
        let totalVolumeSold = new Decimal(0);
        const readingRecords: Array<{
          nozzleId: string;
          opening: Decimal;
          closing: Decimal;
          netSold: Decimal;
          amount: Decimal;
        }> = [];

        for (const [index, item] of nozzleReadings.entries()) {
          const nozzle = await tx.nozzle.findUnique({
            where: { id: item.nozzleId },
            include: { dispenser: { include: { tank: true } } },
          });

          if (!nozzle) {
            throw new ShiftReconciliationError(
              `Nozzle not found: ${item.nozzleId}`,
              'NOZZLE_NOT_FOUND',
              { index, nozzleId: item.nozzleId }
            );
          }

          const opening = nozzle.lastReading;
          const closing = new Decimal(item.closingReading);
          const testing = new Decimal(item.testingVolume || 0);

          // Poka-Yoke: Prevent meter rollback
          if (closing.lessThan(opening)) {
            throw new ShiftReconciliationError(
              `Meter rollback detected on nozzle ${nozzle.nozzleNumber} (Pump ${nozzle.dispenser.pumpNumber}). ` +
                `Opening: ${opening.toFixed(2)}, Closing: ${closing.toFixed(2)}`,
              'METER_ROLLBACK',
              { nozzleId: nozzle.id, opening: opening.toString(), closing: closing.toString() }
            );
          }

          const netSoldVolume = closing.minus(opening).minus(testing);

          // Poka-Yoke: Prevent negative volume
          if (netSoldVolume.lessThan(0)) {
            throw new ShiftReconciliationError(
              `Negative volume calculated for nozzle ${nozzle.nozzleNumber}. ` +
                `Check testing volume (${testing.toFixed(2)}) exceeds meter delta.`,
              'NEGATIVE_VOLUME',
              { nozzleId: nozzle.id, netSoldVolume: netSoldVolume.toString() }
            );
          }

          // Fetch current fuel price
          const fuelPrice = await tx.fuelPrice.findUnique({
            where: { fuelType: nozzle.fuelType },
          });

          if (!fuelPrice || !fuelPrice.isActive) {
            throw new ShiftReconciliationError(
              `No active price found for fuel type: ${nozzle.fuelType}`,
              'FUEL_PRICE_NOT_FOUND',
              { fuelType: nozzle.fuelType }
            );
          }

          const lineAmount = netSoldVolume.times(fuelPrice.sellingPrice);

          totalGrossRevenue = totalGrossRevenue.plus(lineAmount);
          totalVolumeSold = totalVolumeSold.plus(netSoldVolume);

          readingRecords.push({
            nozzleId: nozzle.id,
            opening,
            closing,
            netSold: netSoldVolume,
            amount: lineAmount,
          });

          // Create meter reading record
          await tx.meterReading.create({
            data: {
              shiftId,
              nozzleId: nozzle.id,
              operatorId: shift.attendantId,
              openingReading: opening,
              closingReading: closing,
              testingVolume: testing,
              netSoldVolume,
              unitPrice: fuelPrice.sellingPrice,
              totalAmount: lineAmount,
            },
          });

          // Update nozzle last reading
          await tx.nozzle.update({
            where: { id: nozzle.id },
            data: { lastReading: closing },
          });

          // Decrement tank stock
          const tank = nozzle.dispenser.tank;
          const newStock = tank.currentStock.minus(netSoldVolume);

          if (newStock.lessThan(tank.deadStockLevel)) {
            logger.warn(
              { tankId: tank.id, newStock: newStock.toString(), deadStock: tank.deadStockLevel.toString() },
              'Tank approaching dead stock level'
            );
            await notificationService.alertLowStock(
              tank.tankNumber,
              tank.fuelType,
              newStock.toFixed(2)
            );
          }

          await tx.tank.update({
            where: { id: tank.id },
            data: { currentStock: { decrement: netSoldVolume } },
          });
        }

        // 4. Process payments
        let digitalCollections = new Decimal(0);
        let fleetCreditTotal = new Decimal(0);
        const saleRecords: Array<Prisma.SaleCreateManyShiftInput> = [];

        for (const p of payments) {
          const amount = new Decimal(p.amount);

          if (p.paymentMode === PaymentMode.FLEET_CREDIT) {
            if (!p.customerId) {
              throw new ShiftReconciliationError(
                'Customer ID required for fleet credit payments',
                'MISSING_CUSTOMER_ID',
                { paymentMode: p.paymentMode }
              );
            }

            const customer = await tx.customer.findUnique({
              where: { id: p.customerId },
            });

            if (!customer || !customer.isActive) {
              throw new ShiftReconciliationError(
                `Customer not found or inactive: ${p.customerId}`,
                'INVALID_CUSTOMER',
                { customerId: p.customerId }
              );
            }

            const newBalance = customer.currentBalance.plus(amount);

            // Check credit limit
            if (newBalance.greaterThan(customer.creditLimit)) {
              throw new ShiftReconciliationError(
                `Credit limit exceeded for ${customer.accountName}. ` +
                  `Limit: ${customer.creditLimit.toFixed(2)}, New balance would be: ${newBalance.toFixed(2)}`,
                'CREDIT_LIMIT_EXCEEDED',
                {
                  customerId: customer.id,
                  creditLimit: customer.creditLimit.toString(),
                  attemptedBalance: newBalance.toString(),
                }
              );
            }

            await tx.customer.update({
              where: { id: customer.id },
              data: { currentBalance: newBalance },
            });

            await tx.customerLedger.create({
              data: {
                customerId: customer.id,
                entryType: LedgerEntryType.DEBIT,
                amount,
                balanceAfter: newBalance,
                description: `Fuel purchase - Shift #${shift.shiftNumber}`,
                referenceId: shiftId,
              },
            });

            fleetCreditTotal = fleetCreditTotal.plus(amount);
          } else if (p.paymentMode !== PaymentMode.CASH) {
            digitalCollections = digitalCollections.plus(amount);
          }

          saleRecords.push({
            paymentMode: p.paymentMode,
            amount,
            customerId: p.customerId || null,
          });
        }

        // Bulk create sales
        if (saleRecords.length > 0) {
          await tx.sale.createMany({
            data: saleRecords.map((s) => ({ ...s, shiftId })),
          });
        }

        // 5. Calculate cash reconciliation
        const expectedCash = totalGrossRevenue.minus(digitalCollections).minus(fleetCreditTotal);
        const cashDiscrepancy = actualCash.minus(expectedCash);
        const hasDiscrepancy = cashDiscrepancy.abs().greaterThan(this.DISCREPANCY_THRESHOLD);
        const finalStatus = hasDiscrepancy ? ShiftStatus.DISCREPANCY_FLAGGED : ShiftStatus.CLOSED;

        const cashShortage = cashDiscrepancy.isNegative() ? cashDiscrepancy.abs() : new Decimal(0);

        // 6. Update shift
        const updatedShift = await tx.shift.update({
          where: { id: shiftId },
          data: {
            managerId,
            status: finalStatus,
            closedAt: new Date(),
            totalFuelSales: totalGrossRevenue,
            cashExpected: expectedCash,
            cashCollected: actualCash,
            cashShortage,
            notes: notes || null,
          },
        });

        // 7. Create audit log
        await AuditService.log(
          tx,
          managerId,
          'SHIFT_RECONCILED',
          'Shift',
          shiftId,
          { status: shift.status },
          {
            status: finalStatus,
            totalGrossRevenue: totalGrossRevenue.toString(),
            cashDiscrepancy: cashDiscrepancy.toString(),
            nozzleReadings: readingRecords.map((r) => ({
              nozzleId: r.nozzleId,
              opening: r.opening.toString(),
              closing: r.closing.toString(),
              netSold: r.netSold.toString(),
              amount: r.amount.toString(),
            })),
          },
          ipAddress,
          userAgent
        );

        // 8. Notify if discrepancy
        if (hasDiscrepancy) {
          await notificationService.alertDiscrepancy(
            updatedShift.shiftNumber,
            cashDiscrepancy.abs().toFixed(2)
          );
        }

        logger.info(
          {
            shiftId,
            shiftNumber: updatedShift.shiftNumber,
            status: finalStatus,
            discrepancy: cashDiscrepancy.toString(),
          },
          'Shift reconciliation completed'
        );

        return {
          shiftId,
          shiftNumber: updatedShift.shiftNumber,
          totalGrossRevenue: totalGrossRevenue.toFixed(2),
          totalVolumeSold: totalVolumeSold.toFixed(2),
          cashExpected: expectedCash.toFixed(2),
          cashCollected: actualCash.toFixed(2),
          cashDiscrepancy: cashDiscrepancy.toFixed(2),
          status: finalStatus,
          discrepancyFlagged: hasDiscrepancy,
        };
      },
      {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        maxWait: 10000,
        timeout: 30000,
      }
    );
  }

  public static async getShiftSummary(prisma: PrismaClient, shiftId: string) {
    const shift = await prisma.shift.findUnique({
      where: { id: shiftId },
      include: {
        attendant: { select: { name: true, email: true } },
        manager: { select: { name: true, email: true } },
        meterReadings: {
          include: {
            nozzle: {
              include: {
                dispenser: true,
              },
            },
          },
        },
        sales: {
          include: {
            customer: true,
          },
        },
        _count: { select: { sales: true, meterReadings: true } },
      },
    });

    if (!shift) return null;

    const paymentBreakdown = await prisma.sale.groupBy({
      by: ['paymentMode'],
      where: { shiftId },
      _sum: { amount: true },
    });

    return {
      ...shift,
      paymentBreakdown: paymentBreakdown.map((p) => ({
        mode: p.paymentMode,
        total: p._sum.amount?.toFixed(2) || '0.00',
      })),
    };
  }
}
