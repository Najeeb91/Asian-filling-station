import { Role, ShiftStatus, PaymentMode, FuelType } from '@prisma/client';

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export interface ShiftSummary {
  id: string;
  shiftNumber: number;
  status: ShiftStatus;
  openedAt: Date;
  closedAt: Date | null;
  attendant: { name: string; email: string };
  manager: { name: string; email: string } | null;
  totalFuelSales: string;
  cashExpected: string;
  cashCollected: string;
  cashShortage: string;
  _count: { sales: number; meterReadings: number };
}

export interface DashboardStats {
  totalShiftsToday: number;
  totalRevenueToday: string;
  totalVolumeToday: string;
  activeShifts: number;
  flaggedShifts: number;
  lowStockTanks: number;
}

export interface PaymentBreakdown {
  mode: PaymentMode;
  total: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export type FuelPriceWithHistory = {
  fuelType: FuelType;
  buyingPrice: string;
  sellingPrice: string;
  effectiveFrom: Date;
  isActive: boolean;
};
